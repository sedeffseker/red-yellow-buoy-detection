# buoy-detection > 2026-01-19 5:39pm
https://universe.roboflow.com/imageaiproject/buoy-detection-4hwmm

Provided by a Roboflow user
License: CC BY 4.0

